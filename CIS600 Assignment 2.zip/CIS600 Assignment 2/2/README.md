# I replaced the virtual environmental stations developed using Python with new ones built using the *RIOT-OS* and *MQTT-SN* protocol. I used the native emulator of RIOT-OS to run the stations and generate values over MQTT-SN that need to arrive to the cloud via the MQTT.

# Virtual Sensors
Using *RIOT-OS* I developed an application that represents a virtual environmental station that generates periodically a set of random values for 6 different sensors:

1. Temperature (Range: -50 to 50 Celsius)
2. Humidity (Range: 0 to 100%)
3. Co2 sensor (Range: 300ppm to 2000ppm
4. Rain height (Range: 0 to 50 mm / h)
5. Wind direction (Range: 0 to 360 degrees)
6. Wind intensity (Range: 0 to 100 m/s)

The virtual environmental station uses a unique ID (identity) to publish these random values on an MQTT-SN channel. 
I created several virtual stations running using the native emulator of RIOT-OS and publishing their values on the MQTT-SN channel.

# MQTT-SN broker
I setup a *Really Small Message Broker (RSMB)* where the RIOT-OS applications publish their values over UDP/IPv6. The RSMB is a server implementation of the MQTT and MQTT-SN protocols over Mosquitto.

# MQTT-SN/MQTT transparent bridge
Using *Python* language I developed an MQTT-SN/MQTT transparent bridge. The goal of the bridge is to subscribe to a predefined set of topics on the MQTT-SN broker (e.g., RSMB) and forward all messages received to the same topic on the MQTT broker that is controlled by the cloud-based backend (i.e., publish them). I used the MQTT broker (*AWS IoT*) configured during the previous assignment.
