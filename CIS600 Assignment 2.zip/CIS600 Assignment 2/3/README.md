# I replaced the MQTT protocol and the short-range wireless medium with LoRaWAN and [TheThingsNetwork](https://www.thethingsnetwork.org/), and I developed a new [RIOT-OS](https://riot-os.org/) application that runs on the B-L072Z-LRWAN1 LoRa kit. I used TheThingsNetwork to interconnect the sensor devices with the cloud infrastructure via the MQTT protocol.
Since that I have no real devices of that type, I used [IoT-LAB](https://www.iot-lab.info/) to execute the RIOT-OS application on real sensors.

# LoRaWAN Station
Using RIOT-OS I set up an application that represents a virtual environmental station that generates periodically a set of random values for 6 different sensors:

1. Temperature (Range: -50 to 50 Celsius)
2. Humidity (Range: 0 to 100%)
3. Co2 sensor (Range: 300ppm to 2000ppm
4. Rain height (Range: 0 to 50 mm / h)
5. Wind direction (Range: 0 to 360 degrees)
6. Wind intensity (Range: 0 to 100 m/s)

The virtual environmental station uses a unique ID (identity) to publish these random values on TheThingsNetwork via LoRaWAN, so you can start several instances running on the boards.

# TTN/Cloud transparent bridge
Using *Python* language programming I developed a transparent bridge between the MQTT broker of TTN and the Cloud-based infrastructure configured during the first assignment via *AWS IoT*.
